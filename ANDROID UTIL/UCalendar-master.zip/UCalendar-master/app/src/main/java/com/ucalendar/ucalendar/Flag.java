package com.ucalendar.ucalendar;

public enum Flag
{
    PREVIOUS, NEXT;
}
