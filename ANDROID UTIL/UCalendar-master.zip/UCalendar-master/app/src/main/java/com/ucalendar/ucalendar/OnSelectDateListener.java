package com.ucalendar.ucalendar;

public interface OnSelectDateListener
{
    public void onDateSelected();
}
